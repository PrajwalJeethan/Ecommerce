/**
 * 
 
package com.example.ecommerce.configuration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.example.ecommerce.model.Role;
import com.example.ecommerce.model.User;
import com.example.ecommerce.repository.RoleRepository;
import com.example.ecommerce.repository.UserRepository;

/**
 * @author pmonthei
 *
 
@Component
public class GoogleOAuth2SuccessHandler implements AuthenticationSuccessHandler {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private RedirectStrategy redirectStrategy;
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		
		OAuth2AuthenticationToken token = (OAuth2AuthenticationToken) authentication;
		String email = token.getPrincipal().getAttributes().get("email").toString();
		if(!userRepository.findUserByEmail(email).isPresent()) {
			User user = new User();
			user.setFirstname(token.getPrincipal().getAttributes().get("given_name").toString());
			user.setLastname(token.getPrincipal().getAttributes().get("family_name").toString());
			List<Role> roles = new ArrayList<>();
			roles.add(roleRepository.findById(2L).get());
			user.setRoles(roles);
			userRepository.save(user);
			redirectStrategy.sendRedirect(request, response, "/");
		}
	}

}
*/